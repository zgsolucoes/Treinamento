package zgsolucoes.webinar.refatoracao1

enum TipoProcedimento {
	BASICO, COMUM, AVANCADO
}
