package zgsolucoes.webinar.refatoracao1

class ProcedimentoComum extends Procedimento {
	float obtenhaValor() {
		return 150.00
	}
}
