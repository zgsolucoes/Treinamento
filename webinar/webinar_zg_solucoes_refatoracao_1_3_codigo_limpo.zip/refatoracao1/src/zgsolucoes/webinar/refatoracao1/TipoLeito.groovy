package zgsolucoes.webinar.refatoracao1

enum TipoLeito {
	ENFERMARIA, APARTAMENTO
}
