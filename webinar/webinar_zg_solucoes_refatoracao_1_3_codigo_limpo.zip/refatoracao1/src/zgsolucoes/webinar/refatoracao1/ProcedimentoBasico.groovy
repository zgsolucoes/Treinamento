package zgsolucoes.webinar.refatoracao1

class ProcedimentoBasico extends Procedimento {
	float obtenhaValor() {
		return 50.00
	}
}
