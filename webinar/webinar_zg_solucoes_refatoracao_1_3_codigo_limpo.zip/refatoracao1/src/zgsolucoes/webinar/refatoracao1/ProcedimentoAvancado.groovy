package zgsolucoes.webinar.refatoracao1

class ProcedimentoAvancado extends Procedimento {
	float obtenhaValor() {
		return 500.00
	}
}
